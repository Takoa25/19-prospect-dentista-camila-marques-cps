import { Service, Testimonial, GalleryItem, ContactInfo } from './types';

export const IMAGES = {
    heroBg: 'https://lh3.googleusercontent.com/aida-public/AB6AXuDt1AEqf1WFErn1M4MiFoo8M02mLRTDd4obvPe6KVl48BkSddtNcDGAnWSvoVp8N48U8poEzPsIJiYa7wyHcBxX7B-dti5k5S_hxbY_OuafuwEDNR7d2rJHI13fK2BriqF05tq2MLthoFKHP_TemFa58cc__NlQrpVtPpfLUzbJGAxY2zXppHw2TdDm8ABbiOUKqYowNA9VgsUlQzYH9x1mBI21oqctcx5S4RyHwdawnvHILXKq5_8IVlu77B8tbSbmvSmbefC-7w',
    implant: 'https://lh3.googleusercontent.com/aida-public/AB6AXuDzvxZJm3p1gyZAqRMtlD8WoDtM-C6g9-xQooyZd3m3n_sAJhYC2WBa25bAUNjDUQUm7KRtutLjEpPKEnv5v5e2wmnTWG0-jOCUvdZLnpoCi4ztPkbR34uzgI-Y4opDnpdujcgXUqntsmPs_h_-YT7CMQu_OyZrb53biaTUqqhps2Dj--C1J7oYBib8CplePlzpQtOe5GSm6nJwdKWv4TpCmxqGDtT-w5Gmy0peYv5eGTCxOecUxoouqMSxfE6GhGlDRipBigGdjg',
    tooth: 'https://lh3.googleusercontent.com/aida-public/AB6AXuCxZMuLYX7meFG-rqhzZW8h58TYcBsTSMRZ96dHGBxBkgUlolorkGEu3UULJTjwEURG4TAH50Fq_zPRyQyY8ZiG5HE4prG-xLGJxp5aEjF1Wk9kCeL71orkFaGYaJokB-7nIpUQlIrvEqVXWSmwqUyK7_2VywrCDMB4im0LjEx_PJx3FhYnEIJaVc0hdWOjahULCTj4LaNHEHZhPi2HBFxHs_ibAUx7IXF-fDWQUebOcn6okwwq3re7bWs831VMHTF-f2f12crZRg',
    veneer: 'https://lh3.googleusercontent.com/aida-public/AB6AXuBLh5AK21UkxXOSzz0EJm4TYrlZIwkPb9vTXyOhG2A35OZjDeWwEMmZTlfA7ZqSBfQVMHjUWwkFKJDrGRtld3WCl3IlSkgoQBYFrw9hGgh2VZ228x4n2ZcCsDhAPpTlTD5bUuezuGy2Bz0G2g3ZJ0Li_eH4U5qAGe-nzLUTkfuvQbc3Mp68Q-PjQ5ZoWBdQvauEkH72efEQI32wVBbFo5gPgBGJcBWG3j-3PG4XJSG6ygdYVS-3pC2ah55e8oUPVT-kQ6KGSwQZdA',
    toy: 'https://lh3.googleusercontent.com/aida-public/AB6AXuA8k43xxFA4k37s_LNhr6zjAOtoxK3mdYyZthma8VPY5qXL9jvVP-fJN0yVK6K9H7kz-EakxXcMEwcz2n8GvEEoNQ7XPhMZHb8iXLlPGEPP_KV_3V-a_dWS-9Z-sJpQpEGTWYV4bKahPlxIjiqaVcdmEXOJ-tR-KJbV55RgJM5Na9y0SFAy45doHLRF1pBgqMlhR9uew1c6gFI93qiNUmRDQFuh7WPeEWGlWQtVRFkO1WraHP8-dU3_BXiCxM98NSQCrVLj-FW5_A',
    doctor: 'https://lh3.googleusercontent.com/aida-public/AB6AXuC07b0Tl2HagYGJJp4f2RLPLOthybCcKlSSGCYiEht_f8Ld-Y07X1NeqPrXRpzE_Cd1Lv5eH28ZJp3uV5cpqnxEa2mobHdRhC85tKVzQlcvHux0Nk0cQyYykKsltrUuU21nJmwZcHxtlVJhBAkNaqqgps5mqUcLL4d_MdD0yBwSPQ1sqVwuYdUWdE8xzpr6rZMS-wexV3YQT0-0Gv8aUJ-06Y-oGiY0tboeidEGUNDwLsa-nms6mDtzjVYuFSx5iVqWaHJ1UOxgKw',
    testimonial1: 'https://lh3.googleusercontent.com/aida-public/AB6AXuB90UyZ8leyrV0HZiLYFv8BTsqJ7pg7ahaXV8R6gIE1alZoe9PCD1ij5EIzkU97jCRGkOWc1yT0Uc5fZgCfci8NM_kA6grLp4nvxkH7bjNtH-Y3BDKVXsHDlOSvG2MHMpG55b3yfmaHBhOImpE32qQwyTNil4REHKk7_90dR8_j-LKdn0YvFPkxed8dUfp1lo82ENlgBup0Y2kOCAaGYXCL1cj9hQYULyXP-zUyd47NLbBAAV4HEWDs6c0I2szDJdoL5mZZaLws9Q',
    testimonial2: 'https://lh3.googleusercontent.com/aida-public/AB6AXuARg__npgxvx7HcPBFVZi88HVp_8fY5BurMD2Q9qcTpxpkoEmwpHbRvKezsWcKkDLiXVVesm-zO6RpIs84YmD2x8fjx6VTZHR4hn7EAfi7h7Zv9rxue-NpsAI-qVqaUUsoQY5ndIEHoMjxD7BlPcWOtWdZYPlZq2GC6mFsvzQfAwyhIIMfaGKl75mHrBcohmQG-1mw9QzVbz030pcZzVmyBPd4eoJBEgVGRjSkv4IKv5cilJTSZLYxh-YbST3ZikbGJZeBbpbINbA',
    testimonial3: 'https://lh3.googleusercontent.com/aida-public/AB6AXuA9oRTEcmomWGKZE8lKsNsVLEr5CPIlZ5sT98hWxIR_YG-5EXbBdL60bsiHQNpQAQTGSW4gGigKtDk9Izz_lK-10P7jrbs3idV2bMPzyyarAFMKG4X8annYuBE57ZdEe-tmiEoPvUiK7zpg-aZnVgR9k1LYmOhVg04tq2EyOJYuBdIAVJEqgLzXGtHV49LZazugZrrGplUn6Asg2JifKC-EtPSOySxgTIxCDMoL5zjw1WkH9bM3KT31UYG-AZVwLQJJeXGC1G-3mg',
    testimonial4: 'https://lh3.googleusercontent.com/aida-public/AB6AXuDfKf05E2YRIhT8cX_RtHNt7EqPk8Nmfz5iq3o8TcpY1UGnTQwvRR8EbyBHp8QGoesbdPHHZFGmAClBACN4uvfkfgeZ35TncIIYMoj5ro8yPBcYFATDTwTJwbrEaS8MhApwBWHsuja1Y_rkl-0bLaBM0tTSXlGOUN5_q5pZ8kJgCF7eRouftLQNUovV5FFbsS3TFqXNxnOZ1dLFehI5Dmplcp8CmcN5D7zpKhESNrqyUnzNN9jQlNA5HLrinvzdxZJLGlARurW1Dg',
    reception: 'https://lh3.googleusercontent.com/aida-public/AB6AXuDzsBYdgM_kQjfdS5TuthcywuQRI-hWOvI1aHvpGop5rDjsaWt59pOBvo5ooNVTDuI0vA6IrjuvT_Qn81evTpOpIvnOowFw_iQoCCb2_8eLXPDLYDhnrsCO_m_3BIZVxPDKLxZUeJy_CVbJ8RZuspCPPXQhszsHGNpyAwpa9oBEyD7b6dlT6Pg_zJk-iZ56vXQnKzcX6q0tSE8xggzfo8MTEq5PHqcHlKnOuqLCzei3dXDtPQf5-gX_84OPpEmSd8z7Ykw7SOGPwQ',
    chair: 'https://lh3.googleusercontent.com/aida-public/AB6AXuA5Rw1aEYb3mtH0-hW-idf5g8HS5Fl6A5nwnBKGIFDduTUbBj8UrVPYK011-scAjYLAe2qSq3O6Rbg4ka86jTlx9UMOdTLV-bbVKZa2bxxE1VSuOxzxX5XaSPaPRZmLoUZiBuivm2DMeyxPDLEu29AWtaqMe-7DjtYwLHwI9QFXsnmNpgVLrkEvbokxK97ZToRQv_NbutgnhhzkeEdPFnDDU7xsh8yMEqxKSIEWNwzrOlmdn1vTaAZjbUCZrbleLnO6Yak31aKTbw',
    instruments: 'https://lh3.googleusercontent.com/aida-public/AB6AXuD2km25eAybwlz9UmbKK6vaUoTUf2GPELcMs6Rp2FiB6rOHf82mGTUTe4K3dSqU6Ee3rqIrYiNovGA5_cZBDGAIDE7zuY1-JTDOvUnQYGsYiimQFTH6TUM8c68bT7JF4c9eWvqXlahw8mw1uDL1r5gG4mlEW3rn-WVbIxiosAn2kg_koba-2emqQZcDE0sk2zRh-2OmwuIYcIQdYfhLnyqRMNQtgK0H5Do8z3XUU58lKWKX_iooclqk0BdhmrOjgsHcVxGvX6zvXg',
    equipment: 'https://lh3.googleusercontent.com/aida-public/AB6AXuChODbOyEo7YXFiOwJwpdIpbLSHuu_yaVpM_czBTCnAM4423MAV5vowezL2Kgx5RKfw8T1QYCnBOb4FvE4MQ5ApvBUetkZQsDFBZF8yMvBNw0m9kDHljMpQAthoa1KQHwX4NliNyp4NmKHMksH-EqDAVqxF9EmIERXEaquL7Z39mHZpBZby5r5vql5A1pLC99TRdfdVKVySUoWkIfGYC4CEcXWPno2I4855KIZJ46_EgfrdqFdBJH_aKWKPo3ehslsylKL19Xzsxg',
    corridor: 'https://lh3.googleusercontent.com/aida-public/AB6AXuBZX3SKLFvlGqZO2AdapPdRpzHOQZZXYHrwNxCDc_8jKWbiwn2A5VBwAz8ZjMMye1DaH_ir0uK_HXoUzsGvwfMUzCaRCTmkMOeyno3wxbMdtjg9CS2hFdu-mEDqgBlGEBO8Ac7ZoYCl5fGLPKXPXJUfe9Ie43jETRVu6CJHaux1I-vvWXlDTX0a1yZtpAHDsiqcAW146BjuSGJxoasOeRCMeXnVIiQfhwmBf3DfwiLg81IDPRNAjo5vXM9p1d2PX25xdy2ZLAaEjw',
    mapStatic: 'https://lh3.googleusercontent.com/aida-public/AB6AXuCYT0klDpyiYvoilbfSEF-FVntdIFKRZyhI8tjvFNs9tYk5HqGqPXaSE_fjUaUAVA8LxeYjg0YIyv46sbT-c4_bmCFMJeDkrbp1PU6Uowpo1iOe127JapjW4GTQolnhTDW2k3W-yvG8LA-AlOlVJL23u2SuzkrFFCJWBGmKUAY4klDbiUQqeJiL0eiFfRQmF1xUYfRMLMdMZuRQpvKSjmGiraUbn7PxN2i5ofuQIB0R1rF71BFx1aNea2_1GBvSp3bwtsKlz4dkHQ'
};

export const SERVICES: Service[] = [
    {
        id: '1',
        title: 'Implante Dentário',
        description: 'A solução definitiva para recuperar seu sorriso. Nossos implantes utilizam tecnologia de ponta para garantir estética natural, conforto e durabilidade vitalícia. Recupere sua autoestima e a função mastigatória completa.',
        imageUrl: IMAGES.implant,
        ctaText: 'Saiba mais sobre implantes',
        isFeatured: true
    },
    {
        id: '2',
        title: 'Dente do Siso',
        description: 'Extração segura e humanizada de dentes do siso com foco na recuperação rápida e indolor.',
        imageUrl: IMAGES.tooth,
        isFeatured: false
    },
    {
        id: '3',
        title: 'Facetas em Resina',
        description: 'Sorriso perfeito e harmônico com facetas de resina que transformam a estética dos seus dentes.',
        imageUrl: IMAGES.veneer,
        isFeatured: false
    },
    {
        id: '4',
        title: 'Odontopediatria',
        description: 'Cuidado especial, lúdico e preventivo para garantir a saúde bucal das crianças desde cedo.',
        imageUrl: IMAGES.toy,
        isFeatured: false
    },
    {
        id: '5',
        title: 'Ver mais serviços',
        description: 'Explorar tudo',
        isSeeMore: true,
        isFeatured: false
    }
];

export const TESTIMONIALS: Testimonial[] = [
    {
        id: '1',
        name: 'Ana Silva',
        avatarUrl: IMAGES.testimonial1,
        rating: 5,
        text: '"Fiz meus implantes com a Dra. Camila e o resultado superou todas as minhas expectativas. O atendimento é impecável e me senti muito acolhida desde a primeira consulta."'
    },
    {
        id: '2',
        name: 'Roberto Mendes',
        avatarUrl: IMAGES.testimonial2,
        rating: 5,
        text: '"Profissionalismo e tecnologia de ponta. Fiz clareamento e restauração estética, meu sorriso ficou natural e iluminado. Recomendo para todos!"'
    },
    {
        id: '3',
        name: 'Juliana Costa',
        avatarUrl: IMAGES.testimonial3,
        rating: 4.5,
        text: '"Levo meus filhos na Dra. Camila e eles adoram. A paciência e o carinho com as crianças fazem toda a diferença. O consultório é lindo e super limpo."'
    },
    {
        id: '4',
        name: 'Marcos Oliveira',
        avatarUrl: IMAGES.testimonial4,
        rating: 5,
        text: '"Experiência fantástica do início ao fim. A estrutura da clínica é impressionante e o resultado do meu tratamento ortodôntico foi muito rápido."'
    }
];

export const GALLERY: GalleryItem[] = [
    {
        id: '1',
        title: 'Recepção Confortável',
        description: 'Design pensado no seu bem-estar desde a chegada.',
        imageUrl: IMAGES.reception,
        spanCols: 'md:col-span-2',
        spanRows: 'md:row-span-2'
    },
    {
        id: '2',
        title: 'Salas de Atendimento',
        imageUrl: IMAGES.chair
    },
    {
        id: '3',
        title: 'Biossegurança',
        imageUrl: IMAGES.instruments
    },
    {
        id: '4',
        title: 'Tecnologia Avançada',
        imageUrl: IMAGES.equipment,
        spanCols: 'md:col-span-1'
    },
    {
        id: '5',
        title: 'Ambiente Acolhedor',
        description: 'Espaços amplos e iluminados para sua tranquilidade.',
        imageUrl: IMAGES.corridor,
        spanCols: 'md:col-span-2'
    }
];

export const CONTACT_INFO: ContactInfo = {
    address: 'Av. Pastor João Prata Vieira, 627\nParque dos Servidores, Campinas - SP',
    phone1: '(19) 3256-7890',
    phone2: '(19) 99876-5432',
    email: 'contato@clinicacamilamarques.com.br',
    hoursWeek: 'Seg - Sex: 08:00 - 19:00',
    hoursSat: 'Sáb: 08:00 - 13:00'
};