import React from 'react';
import { useNavigate } from 'react-router-dom';
import { SERVICES } from '../constants';
import { Service } from '../types';

const Services: React.FC = () => {
    return (
        <section className="w-full bg-[#fcf8f9] dark:bg-[#1b0e11] py-24 px-6 sm:px-10" id="servicos">
            <div className="max-w-7xl mx-auto flex flex-col gap-12">
                <div className="text-center max-w-3xl mx-auto flex flex-col gap-4">
                    <h2 className="text-[#1b0e11] dark:text-white text-3xl md:text-4xl font-black leading-tight tracking-[-0.02em]">
                        Nossas Especialidades
                    </h2>
                    <p className="text-gray-600 dark:text-gray-400 text-lg">
                        Oferecemos tratamentos completos para garantir a saúde e a beleza do seu sorriso em todas as fases da vida.
                    </p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                    {SERVICES.map((service) => (
                        <ServiceCard key={service.id} service={service} />
                    ))}
                </div>
            </div>
        </section>
    );
};

const ServiceCard: React.FC<{ service: Service }> = ({ service }) => {
    const navigate = useNavigate();

    if (service.isSeeMore) {
        return (
            <div 
                onClick={() => navigate('/servicos')}
                className="group bg-primary rounded-2xl p-6 flex flex-col justify-between gap-4 shadow-lg shadow-primary/30 hover:bg-primary/90 hover:shadow-primary/40 active:bg-primary/90 active:shadow-primary/40 transition-all duration-500 ease-out hover:scale-[1.03] active:scale-[1.03] cursor-pointer min-h-[260px] relative overflow-hidden focus:outline-none" 
                tabIndex={0}
                role="button"
            >
                <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full blur-2xl -mr-8 -mt-8 pointer-events-none group-hover:scale-125 group-active:scale-125 transition-transform duration-700"></div>
                <div className="absolute bottom-0 left-0 w-24 h-24 bg-black/5 rounded-full blur-xl -ml-8 -mb-8 pointer-events-none group-hover:scale-125 group-active:scale-125 transition-transform duration-700"></div>
                <div className="size-12 rounded-xl bg-white/20 flex items-center justify-center text-white mb-4 backdrop-blur-sm group-hover:rotate-90 group-active:rotate-90 transition-transform duration-500">
                    <span className="material-symbols-outlined text-2xl">add</span>
                </div>
                <div className="relative z-10 transform transition-transform duration-500 group-hover:-translate-y-1 group-active:-translate-y-1">
                    <h3 className="text-white text-2xl font-bold mb-2">{service.title}</h3>
                    <div className="flex items-center gap-2 text-white/90 font-medium mt-4 group-hover:translate-x-2 group-active:translate-x-2 transition-transform duration-300">
                        <span>{service.description}</span>
                        <span className="material-symbols-outlined text-lg">arrow_forward</span>
                    </div>
                </div>
            </div>
        );
    }

    if (service.isFeatured) {
        return (
            <div className="md:col-span-2 md:row-span-2 group bg-white dark:bg-white/5 rounded-2xl border border-[#e7d0d6] dark:border-white/10 p-8 flex flex-col justify-between gap-8 hover:border-primary/50 hover:shadow-2xl hover:shadow-primary/10 active:border-primary/50 active:shadow-2xl active:shadow-primary/10 transition-all duration-500 ease-out hover:scale-[1.01] active:scale-[1.01] cursor-pointer relative overflow-hidden focus:outline-none" tabIndex={0}>
                <div className="absolute top-0 right-0 w-64 h-64 bg-primary/5 rounded-full blur-3xl -mr-16 -mt-16 pointer-events-none group-hover:bg-primary/10 group-active:bg-primary/10 transition-colors duration-500"></div>
                <div className="relative z-10">
                    <div className="w-24 h-24 mb-6 flex items-center justify-center transform transition-transform duration-500 ease-out group-hover:scale-110 group-hover:-translate-y-2 group-hover:rotate-3 group-active:scale-110 group-active:-translate-y-2 group-active:rotate-3">
                        <img src={service.imageUrl} alt={service.title} className="w-full h-full object-contain drop-shadow-lg" />
                    </div>
                    <div className="transform transition-transform duration-500 ease-out group-hover:-translate-y-1 group-active:-translate-y-1">
                        <h3 className="text-[#1b0e11] dark:text-white text-3xl font-bold mb-4">{service.title}</h3>
                        <p className="text-gray-500 dark:text-gray-400 text-lg leading-relaxed max-w-md">
                            {service.description}
                        </p>
                    </div>
                </div>
                <div className="relative z-10 flex items-center gap-2 text-primary font-bold group-hover:gap-4 group-active:gap-4 transition-all mt-auto duration-300">
                    <span>{service.ctaText}</span>
                    <span className="material-symbols-outlined">arrow_forward</span>
                </div>
            </div>
        );
    }

    return (
        <div className="group bg-white dark:bg-white/5 rounded-2xl border border-[#e7d0d6] dark:border-white/10 p-6 flex flex-col justify-between gap-4 hover:border-primary/50 hover:shadow-xl hover:shadow-primary/5 active:border-primary/50 active:shadow-xl active:shadow-primary/5 transition-all duration-500 ease-out hover:scale-[1.03] active:scale-[1.03] cursor-pointer min-h-[260px] focus:outline-none" tabIndex={0}>
            <div className="transform transition-transform duration-500 ease-out group-hover:-translate-y-1 group-active:-translate-y-1">
                <div className="w-16 h-16 mb-4 flex items-center justify-center transform transition-transform duration-500 ease-out group-hover:scale-110 group-hover:-translate-y-2 group-hover:-rotate-3 group-active:scale-110 group-active:-translate-y-2 group-active:-rotate-3">
                    <img src={service.imageUrl} alt={service.title} className="w-full h-full object-contain drop-shadow-md" />
                </div>
                <h3 className="text-[#1b0e11] dark:text-white text-xl font-bold mb-2">{service.title}</h3>
                <p className="text-gray-500 dark:text-gray-400 text-sm leading-relaxed">
                    {service.description}
                </p>
            </div>
        </div>
    );
};

export default Services;