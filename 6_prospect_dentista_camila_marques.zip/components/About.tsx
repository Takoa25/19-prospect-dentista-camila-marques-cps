import React from 'react';
import { IMAGES } from '../constants';

const About: React.FC = () => {
    return (
        <section className="w-full py-24 px-6 sm:px-10 bg-white dark:bg-[#150a0d] relative overflow-hidden" id="sobre">
            {/* Background decorative element */}
            <div className="absolute inset-0 pointer-events-none flex items-center justify-center overflow-hidden">
                <svg className="w-[140%] h-[140%] md:w-[90%] md:h-[90%] max-w-6xl text-primary/5 dark:text-primary/10 transform rotate-12 md:rotate-[15deg] drop-shadow-2xl transition-transform duration-700 hover:scale-105" fill="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path d="M19.34,6.72c-0.23-1.61-0.78-3.07-1.63-4.34C17.2,1.6,16.42,1,15.53,1c-0.65,0-1.29,0.22-1.83,0.67c-1.02,0.85-1.5,2.15-1.7,3.33 C11.8,3.82,11.32,2.52,10.3,1.67C9.76,1.22,9.12,1,8.47,1C7.58,1,6.8,1.6,6.29,2.38C5.44,3.65,4.89,5.11,4.66,6.72 c-0.22,1.52-0.26,3.08,0.1,4.56c0.39,1.63,1.29,3.58,2.37,5.55c1.07,1.96,2.23,3.74,2.77,4.52c0.23,0.34,0.6,0.59,1.01,0.64 c0.74,0.09,1.44-0.41,1.59-1.12c0.04-0.18,0.37-1.89,1.06-3.83c0.07-0.19,0.13-0.38,0.19-0.56c0.81,2.07,1.19,3.77,1.23,3.95 c0.11,0.55,0.6,0.95,1.15,0.95c0.14,0,0.28-0.03,0.42-0.08c0.66-0.25,1.03-0.97,0.86-1.65c-0.45-1.78-1.54-4.88-2.67-7.23 c1.05-1.77,1.97-3.76,2.4-5.34C19.6,9.8,19.56,8.24,19.34,6.72z M8.16,11.13C8.01,10.5,7.9,9.88,7.84,9.25 c-0.07-0.76-0.07-1.52,0-2.26c0.05-0.5,0.14-0.99,0.28-1.47c0.24-0.84,0.6-1.63,1.08-2.32c0.18-0.26,0.39-0.43,0.61-0.43 c0.07,0,0.15,0.02,0.22,0.08c0.41,0.34,0.67,1.02,0.78,1.64c0.26,1.48,0.17,3.04-0.23,4.65c-0.23,0.9-0.58,1.9-1.02,2.83 C9.14,11.75,8.68,11.5,8.16,11.13z M13.91,6.59c0.11-0.62,0.37-1.3,0.78-1.64c0.07-0.06,0.15-0.08,0.22-0.08 c0.22,0,0.43,0.17,0.61,0.43c0.47,0.69,0.83,1.48,1.08,2.32c0.14,0.48,0.23,0.97,0.28,1.47c0.07,0.75,0.07,1.5,0,2.26 c-0.05,0.63-0.17,1.25-0.33,1.87c-0.51,0.37-0.97,0.62-1.39,0.84C14.73,12.74,14.37,11.41,13.91,6.59z"></path>
                </svg>
            </div>

            <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-2 gap-16 items-center relative z-10">
                <div className="relative order-2 lg:order-1">
                    <div className="absolute -top-4 -left-4 w-2/3 h-2/3 bg-primary/5 rounded-2xl -z-10"></div>
                    <div className="absolute -bottom-4 -right-4 w-2/3 h-2/3 bg-primary/5 rounded-2xl -z-10"></div>
                    <img 
                        src={IMAGES.doctor} 
                        alt="Dr. Camila Marques" 
                        className="rounded-2xl shadow-2xl w-full object-cover h-[500px]"
                    />
                    <div className="absolute bottom-8 -right-8 bg-white dark:bg-[#2a171c] p-6 rounded-xl shadow-xl border border-gray-100 dark:border-white/10 max-w-[240px] hidden md:block">
                        <div className="flex items-center gap-2 mb-2">
                            <span className="material-symbols-outlined text-primary">verified</span>
                            <span className="text-sm font-bold text-[#1b0e11] dark:text-white">Certificada</span>
                        </div>
                        <p className="text-xs text-gray-500 dark:text-gray-400">Especialista em Ortodontia e Estética Dental pela USP.</p>
                    </div>
                </div>

                <div className="flex flex-col gap-6 order-1 lg:order-2">
                    <span className="text-primary font-bold text-sm tracking-widest uppercase">Sobre a Dra. Camila</span>
                    <h2 className="text-[#1b0e11] dark:text-white text-3xl md:text-4xl font-black leading-tight">
                        Paixão por criar sorrisos que mudam vidas
                    </h2>
                    <p className="text-gray-600 dark:text-gray-300 text-lg leading-relaxed">
                        Com mais de 10 anos de experiência, a Dra. Camila Marques acredita que um sorriso saudável é a chave para a autoconfiança. Sua abordagem une técnica refinada com um olhar humano e acolhedor.
                    </p>
                    <p className="text-gray-600 dark:text-gray-300 text-lg leading-relaxed">
                        Na nossa clínica, cada paciente é único. Utilizamos equipamentos de última geração para diagnósticos precisos, mas é o nosso cuidado nos detalhes que faz a diferença no seu tratamento.
                    </p>
                    <ul className="flex flex-col gap-3 mt-4">
                        {['Atendimento personalizado e humanizado', 'Equipamentos de alta tecnologia', 'Ambiente moderno e confortável'].map((item, index) => (
                            <li key={index} className="flex items-center gap-3">
                                <span className="material-symbols-outlined text-primary text-xl">check_circle</span>
                                <span className="text-[#1b0e11] dark:text-gray-200 font-medium">{item}</span>
                            </li>
                        ))}
                    </ul>
                    <div className="pt-6">
                        <button className="flex items-center gap-2 text-primary font-bold hover:gap-4 transition-all group w-fit">
                            Conheça nossa equipe
                            <span className="material-symbols-outlined group-hover:translate-x-1 transition-transform">arrow_forward</span>
                        </button>
                    </div>
                </div>
            </div>
        </section>
    );
};

export default About;