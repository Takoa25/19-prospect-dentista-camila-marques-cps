import React from 'react';
import { CONTACT_INFO, IMAGES } from '../constants';

const Contact: React.FC = () => {
    return (
        <section className="w-full py-24 px-6 sm:px-10 bg-[#f8f6f6] dark:bg-[#211115]" id="contato">
            <div className="max-w-7xl mx-auto flex flex-col gap-12">
                <div className="text-center">
                    <h2 className="text-[#1b0e11] dark:text-white text-3xl md:text-4xl font-black leading-tight mb-4">Visite Nossa Clínica</h2>
                    <p className="text-gray-600 dark:text-gray-400">Estamos localizados em uma região privilegiada de Campinas, com fácil acesso e estacionamento.</p>
                </div>

                <div className="bg-white dark:bg-[#150a0d] rounded-2xl shadow-xl overflow-hidden flex flex-col lg:flex-row">
                    {/* Contact Details Sidebar */}
                    <div className="p-8 lg:p-12 lg:w-1/3 bg-primary text-white flex flex-col justify-between relative overflow-hidden">
                        <div className="relative z-10 flex flex-col gap-8">
                            <div>
                                <h3 className="text-2xl font-bold mb-6">Informações de Contato</h3>
                                <div className="flex flex-col gap-6">
                                    <ContactItem icon="location_on" title="Endereço" text={CONTACT_INFO.address} />
                                    <ContactItem icon="call" title="Telefone" text={`${CONTACT_INFO.phone1}\n${CONTACT_INFO.phone2}`} />
                                    <ContactItem icon="mail" title="Email" text={CONTACT_INFO.email} />
                                    <ContactItem icon="schedule" title="Horário" text={`${CONTACT_INFO.hoursWeek}\n${CONTACT_INFO.hoursSat}`} />
                                </div>
                            </div>
                            <div>
                                <button className="w-full py-3 bg-white text-primary font-bold rounded-lg hover:bg-gray-100 transition-colors flex items-center justify-center gap-2">
                                    <span className="material-symbols-outlined">chat</span>
                                    Falar no WhatsApp
                                </button>
                            </div>
                        </div>
                        {/* Decorative circles */}
                        <div className="absolute -bottom-24 -right-24 w-64 h-64 bg-white/10 rounded-full z-0 pointer-events-none"></div>
                        <div className="absolute -top-24 -left-24 w-48 h-48 bg-white/10 rounded-full z-0 pointer-events-none"></div>
                    </div>

                    {/* Map Area */}
                    <div className="lg:w-2/3 h-[400px] lg:h-auto bg-gray-200 dark:bg-gray-800 relative">
                        <div 
                            className="w-full h-full bg-cover bg-center" 
                            style={{ backgroundImage: `url('${IMAGES.mapStatic}')` }}
                        >
                            <div className="w-full h-full flex items-center justify-center bg-gray-300/50 dark:bg-gray-700/50 text-gray-800 backdrop-blur-[1px]">
                                <div className="text-center p-4 bg-white/80 rounded-xl shadow-lg">
                                    <span className="material-symbols-outlined text-4xl mb-2 text-primary">map</span>
                                    <p className="font-medium">Mapa Interativo Google Maps</p>
                                    <p className="text-sm text-gray-600">Av. Pastor João Prata Vieira, 627</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    );
};

const ContactItem: React.FC<{ icon: string; title: string; text: string }> = ({ icon, title, text }) => (
    <div className="flex gap-4 items-start">
        <span className="material-symbols-outlined bg-white/20 p-2 rounded-lg">{icon}</span>
        <div>
            <p className="font-bold text-lg">{title}</p>
            <p className="text-white/90 whitespace-pre-line">{text}</p>
        </div>
    </div>
);

export default Contact;