import React from 'react';
import { TESTIMONIALS } from '../constants';

const Testimonials: React.FC = () => {
    return (
        <section className="w-full py-24 px-6 sm:px-10 bg-[#f8f6f6] dark:bg-[#1b0e11]" id="depoimentos">
            <div className="max-w-7xl mx-auto flex flex-col gap-12">
                <div className="flex flex-col md:flex-row justify-between items-end gap-6">
                    <div className="flex flex-col gap-4 max-w-2xl">
                        <span className="text-primary font-bold text-sm tracking-widest uppercase">Depoimentos</span>
                        <h2 className="text-[#1b0e11] dark:text-white text-3xl md:text-4xl font-black leading-tight tracking-[-0.02em]">
                            O que nossos pacientes dizem
                        </h2>
                        <p className="text-gray-600 dark:text-gray-400 text-lg">
                            Histórias reais de sorrisos transformados e vidas impactadas pelo nosso cuidado.
                        </p>
                    </div>
                    <div className="flex gap-4">
                        <button className="w-12 h-12 rounded-full border border-primary/20 bg-white text-primary hover:bg-primary hover:text-white transition-all flex items-center justify-center shadow-sm">
                            <span className="material-symbols-outlined">arrow_back</span>
                        </button>
                        <button className="w-12 h-12 rounded-full bg-primary text-white hover:bg-primary/90 transition-all flex items-center justify-center shadow-lg shadow-primary/30">
                            <span className="material-symbols-outlined">arrow_forward</span>
                        </button>
                    </div>
                </div>

                <div className="flex gap-6 overflow-x-auto pb-8 snap-x snap-mandatory scrollbar-hide">
                    {TESTIMONIALS.map((testimonial) => (
                        <div key={testimonial.id} className="min-w-[320px] md:min-w-[400px] bg-white dark:bg-white/5 p-8 rounded-2xl border border-gray-100 dark:border-white/10 shadow-sm flex flex-col gap-6 snap-start">
                            <div className="flex items-center gap-4">
                                <img src={testimonial.avatarUrl} alt={testimonial.name} className="w-16 h-16 rounded-full object-cover border-2 border-primary/10" />
                                <div>
                                    <h4 className="font-bold text-[#1b0e11] dark:text-white text-lg">{testimonial.name}</h4>
                                    <div className="flex text-yellow-400 text-sm">
                                        {[...Array(5)].map((_, i) => (
                                            <span key={i} className="material-symbols-outlined text-[18px] fill-current">
                                                {i < Math.floor(testimonial.rating) ? 'star' : (i < testimonial.rating ? 'star_half' : 'star_border')}
                                            </span>
                                        ))}
                                    </div>
                                </div>
                            </div>
                            <p className="text-gray-600 dark:text-gray-300 italic leading-relaxed">
                                {testimonial.text}
                            </p>
                        </div>
                    ))}
                </div>
            </div>
        </section>
    );
};

export default Testimonials;