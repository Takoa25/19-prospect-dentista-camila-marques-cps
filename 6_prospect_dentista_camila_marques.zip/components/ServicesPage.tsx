import React from 'react';
import Header from './Header';
import Footer from './Footer';

const ServicesPage: React.FC = () => {
    return (
        <div className="flex min-h-screen w-full flex-col relative">
            <Header />
            
            <section className="relative flex w-full flex-col items-center justify-center bg-gradient-to-b from-[#FEF2F5] to-background-light py-16 text-center dark:from-[#2d1b20] dark:to-background-dark lg:py-32 pt-32">
                <div className="absolute inset-0 overflow-hidden opacity-30 pointer-events-none">
                    <div className="absolute -right-20 top-20 h-96 w-96 rounded-full bg-primary/10 blur-3xl"></div>
                    <div className="absolute -left-20 bottom-20 h-72 w-72 rounded-full bg-blue-200/20 blur-3xl"></div>
                </div>
                <div className="relative z-10 mx-auto max-w-4xl px-6 animate-fade-in-up">
                    <span className="mb-4 inline-block rounded-full bg-primary/10 px-4 py-1.5 text-xs font-bold uppercase tracking-wider text-primary">Excelência em Odontologia</span>
                    <h1 className="mb-6 text-3xl font-extrabold tracking-tight text-text-main dark:text-white md:text-5xl lg:text-6xl">
                        Nossas Especialidades
                    </h1>
                    <p className="mx-auto max-w-2xl text-base text-text-secondary dark:text-gray-300 md:text-xl md:leading-relaxed">
                        Unimos tecnologia de ponta e atendimento humanizado para oferecer os melhores tratamentos. Descubra como podemos transformar o seu sorriso.
                    </p>
                </div>
            </section>

            <main className="flex-1 bg-background-light px-4 py-8 dark:bg-background-dark lg:px-20 lg:py-20">
                <div className="mx-auto max-w-[1440px]">
                    <div className="grid grid-cols-2 grid-flow-dense gap-4 md:grid-cols-2 lg:grid-cols-4 lg:grid-rows-[360px_360px_360px_360px] xl:gap-8">
                        
                        {/* Implantes */}
                        <div className="bento-card group relative col-span-2 h-80 overflow-hidden rounded-2xl bg-surface-light shadow-card dark:bg-surface-dark lg:col-span-2 lg:row-span-2 lg:h-full" tabIndex={0}>
                            <div className="absolute inset-0 z-0 h-full w-full overflow-hidden bg-gray-200 dark:bg-gray-800">
                                <img alt="Implantes Dentários" loading="lazy" className="bento-image h-full w-full object-cover opacity-90 transition-opacity group-hover:opacity-100" src="https://lh3.googleusercontent.com/aida-public/AB6AXuCjVYQZDOHPv8qIfR27kemE_oEkrbt3SVj0l_iOyuhu_icBG5y-kLvIQ8t-IHkRYM-dYUEe00jTRMFl28_SKgKQJk8WSTdL_dsTEdDnoXb_6shvZ-MFtZLfYXg3JkbkaBiWA6VJx5kjwSd47fPMWmjBjeft044QRRwfmibxh-qFgZxM7gSijXuAkz7jVrwpkMivbywkaXasfxQNO-7MhXxcRLvl5U49_-qOqeLiS-PpHzM_1FDzIsTWaMRJdfLJNEIG7MZPVpXBhQ"/>
                                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent"></div>
                            </div>
                            <div className="bento-content relative z-10 flex h-full flex-col justify-end p-6 md:p-8 text-white">
                                <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-xl bg-primary/90 text-white backdrop-blur-md md:h-14 md:w-14">
                                    <span className="material-symbols-outlined text-2xl md:text-[32px]">medical_services</span>
                                </div>
                                <h3 className="mb-2 text-2xl font-bold md:text-3xl">Implantes Dentários</h3>
                                <p className="mb-4 max-w-md text-sm md:text-lg text-gray-200">
                                    Restaure a função mastigatória e a estética do seu sorriso com implantes de titânio.
                                </p>
                                <a className="inline-flex items-center text-sm font-bold text-white/90 hover:text-primary hover:underline" href="#">
                                    Saber mais <span className="material-symbols-outlined ml-1 text-base">arrow_forward</span>
                                </a>
                            </div>
                        </div>

                        {/* Ortodontia */}
                        <div className="bento-card group relative col-span-1 h-60 overflow-hidden rounded-2xl bg-surface-light shadow-card dark:bg-surface-dark lg:col-span-1 lg:row-span-1 lg:h-full" tabIndex={0}>
                            <div className="absolute inset-0 z-0 h-full w-full overflow-hidden bg-gray-200 dark:bg-gray-800">
                                <img alt="Ortodontia" loading="lazy" className="bento-image h-full w-full object-cover opacity-90 transition-opacity group-hover:opacity-100" src="https://lh3.googleusercontent.com/aida-public/AB6AXuCfz3G9NZ32dFPlQsDf9qWwKah7Z029L6_WBsp7j1Fa1DK1MmrdQHbMWC_Hlsnzq9JqWHW_KloTjVamUCZF0vmtZ7YKeRlskAgykrAGJoM4c42D2JCnfS4uizY-1oaG4pkrgPl1hUmXw7LMRlod4BvjVlGciA1PD04q44fHOiRy099lSU7gGPYBk-rXLxfnTK40NUqPnzCysd_MaB2UF8KDnoerLSZ2R2QNTrWmrXjXKsRU65slifs_QiOi0f_4CSqnuDoT8nIvmg"/>
                                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent"></div>
                            </div>
                            <div className="bento-content relative z-10 flex h-full flex-col justify-end p-4 md:p-6 text-white">
                                <div className="mb-2 md:mb-3 flex h-8 w-8 md:h-10 md:w-10 items-center justify-center rounded-lg bg-white/20 backdrop-blur-md">
                                    <span className="material-symbols-outlined text-lg md:text-xl text-white">all_inclusive</span>
                                </div>
                                <h3 className="text-lg md:text-xl font-bold">Ortodontia</h3>
                                <p className="mt-1 md:mt-2 text-xs md:text-sm text-gray-200 line-clamp-2">Aparelhos estéticos e alinhadores.</p>
                            </div>
                        </div>

                        {/* Lentes */}
                        <div className="bento-card group relative col-span-1 h-60 overflow-hidden rounded-2xl bg-surface-light shadow-card dark:bg-surface-dark lg:col-span-1 lg:row-span-1 lg:h-full" tabIndex={0}>
                            <div className="absolute inset-0 z-0 h-full w-full overflow-hidden bg-gray-200 dark:bg-gray-800">
                                <img alt="Lentes de Contato" loading="lazy" className="bento-image h-full w-full object-cover opacity-90 transition-opacity group-hover:opacity-100" src="https://lh3.googleusercontent.com/aida-public/AB6AXuC-_1k6HQd-usj-GADVEALtrVs5CDdUUPSU9jUaHV1dF4_qTqIHiOAvbiOg3cA8N151wDX_Y7AToELuCGWjJcTBsxWaY-kgXjjEoWfjG65pKZANU2vSy-w7Laip_lm88Jq_V930yZNVHgCNp04SiGZOUthQOQRTUvcvRauMnBcc_MXR5PPlNtx4FHndGWzbe-3RL3lofzGSD7knIz7G4soneyVRsVodvPiB4BzXEUW68UkeTF4GcYWIC4roBmnBXwbpN7kXLv1lbQ"/>
                                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent"></div>
                            </div>
                            <div className="bento-content relative z-10 flex h-full flex-col justify-end p-4 md:p-6 text-white">
                                <div className="mb-2 md:mb-3 flex h-8 w-8 md:h-10 md:w-10 items-center justify-center rounded-lg bg-white/20 backdrop-blur-md">
                                    <span className="material-symbols-outlined text-lg md:text-xl text-white">auto_awesome</span>
                                </div>
                                <h3 className="text-lg md:text-xl font-bold">Lentes</h3>
                                <p className="mt-1 md:mt-2 text-xs md:text-sm text-gray-200 line-clamp-2">Facetas de porcelana.</p>
                            </div>
                        </div>

                        {/* Clareamento */}
                        <div className="bento-card group relative col-span-2 h-72 overflow-hidden rounded-2xl bg-surface-light shadow-card dark:bg-surface-dark lg:col-span-1 lg:row-span-2 lg:h-full" tabIndex={0}>
                            <div className="absolute inset-0 z-0 h-full w-full overflow-hidden bg-gray-200 dark:bg-gray-800">
                                <img alt="Clareamento Dental" loading="lazy" className="bento-image h-full w-full object-cover opacity-90 transition-opacity group-hover:opacity-100" src="https://lh3.googleusercontent.com/aida-public/AB6AXuDFrRwDd9pec2SssqtN0KW9qstzKvVAM44QGXt6FbYUuGuZDwjIQzg0XcYsdq50DVYuxIkoXvYAWmIqjz6RNGQACB_Vv0FhS6AfL973dCv4hckakiWxHV043Vj1mhnvOh2aWyjLATc8n8gfEbFlQp19uOf0XbaUEbQHbReGKjy5GuaHqkPD-niX10gkqsRm83TmRskI2bRQUZCtxHPiRjZnNl1zM5ZcLTTZA6tLD_WP8Nu32_yMCSwU8M5Ijq1PcNF2CyxSgc2N7g"/>
                                <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/10 to-transparent"></div>
                            </div>
                            <div className="bento-content relative z-10 flex h-full flex-col justify-end p-6 text-white">
                                <div className="mb-4 flex h-10 w-10 md:h-12 md:w-12 items-center justify-center rounded-xl bg-white/20 backdrop-blur-md">
                                    <span className="material-symbols-outlined text-xl md:text-2xl text-white">light_mode</span>
                                </div>
                                <h3 className="mb-2 text-xl md:text-2xl font-bold">Clareamento</h3>
                                <p className="text-sm leading-relaxed text-gray-200">
                                    Procedimentos a laser ou caseiros para iluminar seu sorriso.
                                </p>
                            </div>
                        </div>

                        {/* Kids */}
                        <div className="bento-card group relative col-span-1 h-60 overflow-hidden rounded-2xl bg-surface-light shadow-card dark:bg-surface-dark lg:col-span-1 lg:row-span-1 lg:h-full" tabIndex={0}>
                            <div className="absolute inset-0 z-0 h-full w-full overflow-hidden bg-gray-200 dark:bg-gray-800">
                                <img alt="Odontopediatria" loading="lazy" className="bento-image h-full w-full object-cover opacity-90 transition-opacity group-hover:opacity-100" src="https://lh3.googleusercontent.com/aida-public/AB6AXuAQ1EqB3vKBv-LIOomB_QsBO22Ck2Tt3ZhoUbSz3zi9Vfa3TeGhWq4x6L4D18DzRe4ooL45JC_2RltsUfvX6rguR_P2o5N-j7nxCmksTGV0fivwFVaHEIOe5LAF6JrNcWhkRo4PbVCIAObNSAmJzwTC7Zd6AvcrTNkU3cmGD1R6e1krUltuLtSM-Sgr0OISbvtPoqY80C5fobA-SEoASC_bEqpvGu6Tgaeo8zJMfaFa4W7J3U6pzvifeGQK0Y5-Gp0J0_TPhqTAHA"/>
                                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent"></div>
                            </div>
                            <div className="bento-content relative z-10 flex h-full flex-col justify-end p-4 md:p-6 text-white">
                                <div className="mb-2 md:mb-3 flex h-8 w-8 md:h-10 md:w-10 items-center justify-center rounded-lg bg-white/20 backdrop-blur-md">
                                    <span className="material-symbols-outlined text-lg md:text-xl text-white">child_care</span>
                                </div>
                                <h3 className="text-lg md:text-xl font-bold">Kids</h3>
                                <p className="mt-1 md:mt-2 text-xs md:text-sm text-gray-200 line-clamp-2">Cuidado lúdico para crianças.</p>
                            </div>
                        </div>

                        {/* Harmonização */}
                        <div className="bento-card group relative col-span-2 h-80 overflow-hidden rounded-2xl bg-surface-light shadow-card dark:bg-surface-dark lg:col-span-2 lg:row-span-1 lg:h-full" tabIndex={0}>
                            <div className="absolute inset-0 z-0 h-full w-full overflow-hidden bg-gray-200 dark:bg-gray-800">
                                <img alt="Harmonização Facial" loading="lazy" className="bento-image h-full w-full object-cover object-[50%_30%] opacity-90 transition-opacity group-hover:opacity-100" src="https://lh3.googleusercontent.com/aida-public/AB6AXuCdemQqeE52UrLlAZNoeSyveDUwaKR1VBZh-fyQnwji0voN7f5fAC9yIgZkAet7690rirWFbPXq_LH5wCgb6MYSC0M18y-qh6EC8ARh10Is2vP797CBFQw9pvEQ5BLFinNlXIWsJBJXrkVTqvn5rqxwwN-lrUtzvJ-QiCvClZvL-I3tS0Qxfhfb3jTYToBitk_w37I5p158G5L6-tyBxchQ0BAX6iyabSj1L7Wa6m4-kU9mLfcXKKagswSeHO6hClqn4LfVRCr9ew"/>
                                <div className="absolute inset-0 bg-gradient-to-r from-black/80 via-black/40 to-transparent"></div>
                            </div>
                            <div className="bento-content relative z-10 flex h-full flex-col justify-center p-6 md:p-8 text-white">
                                <div className="mb-3 flex h-10 w-10 md:h-12 md:w-12 items-center justify-center rounded-xl bg-white/20 backdrop-blur-md">
                                    <span className="material-symbols-outlined text-xl md:text-2xl text-white">face</span>
                                </div>
                                <h3 className="mb-2 text-xl md:text-2xl font-bold">Harmonização Facial</h3>
                                <p className="max-w-md text-sm md:text-base text-gray-200">
                                    Realce sua beleza natural com procedimentos minimamente invasivos.
                                </p>
                            </div>
                        </div>

                        {/* Siso */}
                        <div className="bento-card group relative col-span-1 h-60 overflow-hidden rounded-2xl bg-surface-light shadow-card dark:bg-surface-dark lg:col-span-1 lg:row-span-1 lg:h-full" tabIndex={0}>
                            <div className="absolute inset-0 z-0 h-full w-full overflow-hidden bg-gray-200 dark:bg-gray-800">
                                <img alt="Extração do Siso" loading="lazy" className="bento-image h-full w-full object-cover opacity-90 transition-opacity group-hover:opacity-100" src="https://lh3.googleusercontent.com/aida-public/AB6AXuBMvgo6fK_En6_HTn314_Hn9ft9-zrr6M233vvgP-ejmr7TI9qlsbSyBZN-2lcptYls1hrpPR6DDSSh82urHAIyWtO5pZMNF-Mz_ZErdT_iHDr6oYI18Q43qntRmNeR-ZhDWjo4ti2eP-xaQMtIjk7cMKjyY1W0ih8LQ0FovfGcAzmab_WLBNnGkxW7GH90DuPjqEaEFpbGZbMm6H3CnAGwUJgLLHjrDUMqVC0JfM4pImmTIOTV2gVuETqbHxFgornpyV6PsUaG1w"/>
                                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent"></div>
                            </div>
                            <div className="bento-content relative z-10 flex h-full flex-col justify-end p-4 md:p-6 text-white">
                                <div className="mb-2 md:mb-3 flex h-8 w-8 md:h-10 md:w-10 items-center justify-center rounded-lg bg-white/20 backdrop-blur-md">
                                    <span className="material-symbols-outlined text-lg md:text-xl text-white">dentistry</span>
                                </div>
                                <h3 className="text-lg md:text-xl font-bold">Siso</h3>
                                <p className="mt-1 md:mt-2 text-xs md:text-sm text-gray-200">Cirurgia segura.</p>
                            </div>
                        </div>

                        {/* Endodontia */}
                        <div className="bento-card group relative col-span-2 h-64 overflow-hidden rounded-2xl bg-surface-light shadow-card dark:bg-surface-dark lg:col-span-1 lg:row-span-2 lg:h-full" tabIndex={0}>
                            <div className="absolute inset-0 z-0 h-full w-full overflow-hidden bg-gray-200 dark:bg-gray-800">
                                <img alt="Endodontia" loading="lazy" className="bento-image h-full w-full object-cover opacity-90 transition-opacity group-hover:opacity-100" src="https://lh3.googleusercontent.com/aida-public/AB6AXuBRm-2oJSaJ668KEjVt0Yvg76HFSp2rPbhy3Iqmg_quwj7wNCMLcrRdska6cCDjARu-wE_upj7V3AZk3BS6cOnAwfKKLvTXKlH7DZqvp93XrqsR1Mx5-i34SB5--g87Gs6TzQuxbE5-rpc_v_EyJiDG0WmTJ1LM1f3NzmfEYBKpxFEzscHju8ib8u0R_DUDh4DMotWTxZ82AgWZ9L4DMMLNaDHxVlH7nM1N01p4Mq-jWgzaCdec9e-6zOIj21-GiWHZUVeerbZI_g"/>
                                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/10 to-transparent"></div>
                            </div>
                            <div className="bento-content relative z-10 flex h-full flex-col justify-end p-6 text-white">
                                <div className="mb-4 flex h-10 w-10 md:h-12 md:w-12 items-center justify-center rounded-xl bg-white/20 backdrop-blur-md">
                                    <span className="material-symbols-outlined text-xl md:text-2xl text-white">healing</span>
                                </div>
                                <h3 className="mb-2 text-xl md:text-2xl font-bold">Endodontia</h3>
                                <p className="text-sm leading-relaxed text-gray-200">
                                    Tratamento de canal com microscopia para salvar dentes.
                                </p>
                            </div>
                        </div>

                        {/* Periodontia */}
                        <div className="bento-card group relative col-span-2 h-72 overflow-hidden rounded-2xl bg-surface-light shadow-card dark:bg-surface-dark lg:col-span-2 lg:row-span-1 lg:h-full" tabIndex={0}>
                            <div className="absolute inset-0 z-0 h-full w-full overflow-hidden bg-gray-200 dark:bg-gray-800">
                                <img alt="Periodontia" loading="lazy" className="bento-image h-full w-full object-cover object-center opacity-90 transition-opacity group-hover:opacity-100" src="https://lh3.googleusercontent.com/aida-public/AB6AXuDmvioeOy04bntKCtFAtEJIz0uBj401QZqsrwUoCdENzGn5rPZtdvC76G6lq28xDUCDs4tWiVPqVTIFjAyhn88fYcb11KeU1HD110ZJEeLqZZwHhP5JhV3Q6UAHjmXKHrUEgpuWlMF9DwaX-J41kt64jK2xae7zznztDN-sydgxzM-v44lQ6GDA50Lhj8zasA0XenjvVi8wKsZEKlZ_UHShwMNNF5iihIMA8RPgEKUWEdGis61R9mLlsRytoICYpsOvQD2Nmm1GGw"/>
                                <div className="absolute inset-0 bg-gradient-to-r from-black/80 via-black/40 to-transparent"></div>
                            </div>
                            <div className="bento-content relative z-10 flex h-full flex-col justify-center p-6 md:p-8 text-white">
                                <div className="mb-3 flex h-10 w-10 md:h-12 md:w-12 items-center justify-center rounded-xl bg-white/20 backdrop-blur-md">
                                    <span className="material-symbols-outlined text-xl md:text-2xl text-white">water_drop</span>
                                </div>
                                <h3 className="mb-2 text-xl md:text-2xl font-bold">Periodontia</h3>
                                <p className="max-w-md text-sm md:text-base text-gray-200">
                                    Saúde das gengivas e tecidos de sustentação.
                                </p>
                            </div>
                        </div>

                        {/* Call to Action Card */}
                        <div className="bento-card group relative col-span-2 flex items-center justify-center overflow-hidden rounded-2xl bg-primary p-6 text-center shadow-card transition-transform hover:scale-[1.02] active:scale-[0.98] dark:bg-[#b01e42] lg:col-span-1 lg:row-span-1 lg:h-full" tabIndex={0}>
                            <div className="relative z-10 flex flex-col items-center gap-4">
                                <h3 className="text-xl md:text-2xl font-extrabold text-white">Agende sua Avaliação</h3>
                                <p className="text-sm font-medium text-white/90">Dê o primeiro passo para o seu novo sorriso.</p>
                                <a className="mt-2 flex h-10 w-10 items-center justify-center rounded-full bg-white text-primary transition-colors hover:bg-white/90" href="#">
                                    <span className="material-symbols-outlined">arrow_forward</span>
                                </a>
                            </div>
                            <div className="absolute -right-10 -top-10 h-32 w-32 rounded-full bg-white/10 blur-2xl"></div>
                            <div className="absolute -bottom-10 -left-10 h-32 w-32 rounded-full bg-white/10 blur-2xl"></div>
                        </div>
                    </div>
                </div>
            </main>

            <section className="@container bg-primary py-20 text-white dark:bg-[#b01e42]">
                <div className="mx-auto flex max-w-[1440px] flex-col items-center justify-center gap-8 px-6 text-center md:px-20">
                    <div className="flex flex-col gap-4">
                        <h2 className="max-w-[800px] font-display text-4xl font-extrabold leading-tight tracking-tight md:text-5xl">
                            Pronto para transformar seu sorriso?
                        </h2>
                        <p className="mx-auto max-w-2xl text-lg font-medium text-white/90">
                            Agende uma avaliação inicial e descubra o plano de tratamento ideal para você. Nossa equipe está pronta para atendê-lo.
                        </p>
                    </div>
                    <button className="flex min-w-[200px] cursor-pointer items-center justify-center gap-3 rounded-xl bg-white px-8 py-4 text-lg font-extrabold text-primary shadow-lg transition-transform hover:scale-105 active:scale-95 dark:bg-white dark:text-[#b01e42]">
                        <span className="material-symbols-outlined">chat</span>
                        Agendar via WhatsApp
                    </button>
                </div>
            </section>
            
            <Footer />
        </div>
    );
};

export default ServicesPage;