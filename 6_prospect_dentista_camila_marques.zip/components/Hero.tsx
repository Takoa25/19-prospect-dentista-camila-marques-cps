import React from 'react';
import { IMAGES } from '../constants';

const Hero: React.FC = () => {
    return (
        <section className="w-full relative h-[650px] flex items-center justify-center overflow-hidden">
            <div 
                className="absolute inset-0 w-full h-full bg-cover bg-center" 
                style={{ backgroundImage: `url('${IMAGES.heroBg}')` }}
                aria-label="Modern dental office waiting area"
            >
            </div>
            <div className="absolute inset-0 bg-gradient-to-r from-white/90 via-white/60 to-transparent dark:from-black/90 dark:via-black/60 dark:to-transparent"></div>
            
            <div className="relative z-10 w-full max-w-7xl px-6 sm:px-10 flex flex-col gap-6">
                <div className="max-w-[640px] flex flex-col gap-4 animate-fade-in-up">
                    <span className="inline-block px-3 py-1 bg-primary/10 dark:bg-primary/20 text-primary text-xs font-bold rounded-full w-fit uppercase tracking-wider">
                        Odontologia Especializada em Campinas
                    </span>
                    <h1 className="text-[#1b0e11] dark:text-white text-5xl md:text-6xl font-black leading-[1.1] tracking-[-0.033em]">
                        Transformando Sorrisos com Excelência e Carinho
                    </h1>
                    <p className="text-gray-700 dark:text-gray-300 text-lg font-medium leading-relaxed max-w-[500px]">
                        Sua clínica de excelência em Campinas, SP. Cuidamos do seu sorriso com tecnologia de ponta e um atendimento humanizado que você merece.
                    </p>
                    <div className="pt-4 flex gap-4">
                        <button className="h-12 px-8 bg-primary hover:bg-primary/90 text-white text-base font-bold rounded-lg shadow-lg shadow-primary/40 transition-all hover:-translate-y-0.5">
                            Agendar Consulta
                        </button>
                        <button className="h-12 px-8 bg-white dark:bg-white/10 border border-gray-200 dark:border-white/20 text-[#1b0e11] dark:text-white hover:bg-gray-50 dark:hover:bg-white/20 text-base font-bold rounded-lg transition-all">
                            Saiba Mais
                        </button>
                    </div>
                </div>
            </div>
        </section>
    );
};

export default Hero;