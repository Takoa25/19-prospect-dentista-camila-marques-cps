import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

const Header: React.FC = () => {
    const [isMenuOpen, setIsMenuOpen] = useState(false);
    const navigate = useNavigate();

    const handleNavigation = (path: string, hash?: string) => {
        setIsMenuOpen(false);
        if (path === '/') {
            navigate('/');
            if (hash) {
                setTimeout(() => {
                    const element = document.getElementById(hash);
                    if (element) {
                        element.scrollIntoView({ behavior: 'smooth' });
                    }
                }, 100);
            } else {
                window.scrollTo({ top: 0, behavior: 'smooth' });
            }
        } else {
            navigate(path);
        }
    };

    return (
        <header className="fixed top-0 left-0 w-full z-50 bg-[#fcf8f9]/90 backdrop-blur-md border-b border-[#f3e7ea] dark:bg-[#1b0e11]/90 dark:border-white/10 transition-colors">
            <div className="max-w-7xl mx-auto px-6 sm:px-10 py-3 flex items-center justify-between whitespace-nowrap">
                <div 
                    className="flex items-center gap-4 text-primary cursor-pointer"
                    onClick={() => handleNavigation('/')}
                >
                    <div className="size-8 text-primary">
                        <span className="material-symbols-outlined text-3xl">dentistry</span>
                    </div>
                    <h2 className="text-[#1b0e11] dark:text-white text-xl font-bold leading-tight tracking-[-0.015em]">Camila Marques</h2>
                </div>
                
                <div className="hidden lg:flex flex-1 justify-end gap-8 items-center">
                    <div className="flex items-center gap-9">
                        <button onClick={() => handleNavigation('/')} className="text-[#1b0e11] dark:text-gray-200 text-sm font-medium leading-normal hover:text-primary transition-colors bg-transparent border-none cursor-pointer">Início</button>
                        <button onClick={() => handleNavigation('/', 'servicos')} className="text-[#1b0e11] dark:text-gray-200 text-sm font-medium leading-normal hover:text-primary transition-colors bg-transparent border-none cursor-pointer">Serviços</button>
                        <button onClick={() => handleNavigation('/', 'sobre')} className="text-[#1b0e11] dark:text-gray-200 text-sm font-medium leading-normal hover:text-primary transition-colors bg-transparent border-none cursor-pointer">Sobre</button>
                        <button onClick={() => handleNavigation('/', 'depoimentos')} className="text-[#1b0e11] dark:text-gray-200 text-sm font-medium leading-normal hover:text-primary transition-colors bg-transparent border-none cursor-pointer">Depoimentos</button>
                        <button onClick={() => handleNavigation('/', 'espaco')} className="text-[#1b0e11] dark:text-gray-200 text-sm font-medium leading-normal hover:text-primary transition-colors bg-transparent border-none cursor-pointer">Nosso Espaço</button>
                        <button onClick={() => handleNavigation('/', 'contato')} className="text-[#1b0e11] dark:text-gray-200 text-sm font-medium leading-normal hover:text-primary transition-colors bg-transparent border-none cursor-pointer">Contato</button>
                    </div>
                    <button className="flex min-w-[84px] cursor-pointer items-center justify-center overflow-hidden rounded-lg h-10 px-6 bg-primary hover:bg-primary/90 transition-colors text-white text-sm font-bold leading-normal tracking-[0.015em] shadow-lg shadow-primary/30">
                        <span className="truncate">Agendar Consulta</span>
                    </button>
                </div>
                
                <div className="lg:hidden text-[#1b0e11] dark:text-white" onClick={() => setIsMenuOpen(!isMenuOpen)}>
                    <span className="material-symbols-outlined cursor-pointer select-none">menu</span>
                </div>
            </div>

            {/* Mobile Menu */}
            {isMenuOpen && (
                <div className="lg:hidden absolute top-full left-0 w-full bg-white dark:bg-[#1b0e11] border-b border-gray-100 dark:border-white/10 p-6 flex flex-col gap-4 shadow-xl animate-fade-in-up">
                    <button onClick={() => handleNavigation('/')} className="text-lg font-medium hover:text-primary text-left">Início</button>
                    <button onClick={() => handleNavigation('/', 'servicos')} className="text-lg font-medium hover:text-primary text-left">Serviços</button>
                    <button onClick={() => handleNavigation('/', 'sobre')} className="text-lg font-medium hover:text-primary text-left">Sobre</button>
                    <button onClick={() => handleNavigation('/', 'depoimentos')} className="text-lg font-medium hover:text-primary text-left">Depoimentos</button>
                    <button onClick={() => handleNavigation('/', 'espaco')} className="text-lg font-medium hover:text-primary text-left">Nosso Espaço</button>
                    <button onClick={() => handleNavigation('/', 'contato')} className="text-lg font-medium hover:text-primary text-left">Contato</button>
                    <button className="mt-2 w-full h-12 bg-primary text-white font-bold rounded-lg shadow-lg" onClick={() => setIsMenuOpen(false)}>
                        Agendar Consulta
                    </button>
                </div>
            )}
        </header>
    );
};

export default Header;